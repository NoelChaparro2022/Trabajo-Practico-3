
drop database pizzeria;
create database pizzeria;
use pizzeria;
-- -----------------------------------------------------
drop table if exists clientes;
create table clientes  
(
id  int not null,
nombre varchar (45),
telefono int (11),
id_gusto int,
PRIMARY KEY (id)
);

select*from clientes;
-- -----------------------------------------------------
drop table if exists Venta;

create table Venta(

  id int,
  id_cliente int,
  id_empleado int,
  fecha_venta  date not null,
  id_tipo_pizza int not null,
  cantidad_vendida int not null,
  precio double);
  
 select*from  venta;
  -- -----------------------------------------------------
drop table if exists tipoPizza;

create table tipoPizza( 
  id int auto_increment,
  primary key (id),
  tipo_pizza enum('fugazzeta','morron','muzarella','Jamon') ,
  precio double,
 ingredientes varchar(180)
       );
       
       select*from tipoPizza;
    -- -----------------------------------------------------
drop table if exists empleados;  

create table empleados (
  id int auto_increment,
  nombre varchar(45),
  apellido varchar(45),
  horas_trabajadas int not null,
  primary key (id)
);
      select*from empleados;
-- ------------------------------------------------------------------------------------------
      
alter table Venta add constraint fk_Venta_idPizzas foreign key (id_tipo_pizza) references tipoPizza(id);

alter table Venta add constraint fk_idEmpleado foreign key (id_empleado) references empleados(id);

alter table Venta add constraint fk_orden_cliente foreign key (id_cliente) references clientes(id);

alter table clientes add constraint fk_cliente foreign key (id) references tipoPizza(id);

