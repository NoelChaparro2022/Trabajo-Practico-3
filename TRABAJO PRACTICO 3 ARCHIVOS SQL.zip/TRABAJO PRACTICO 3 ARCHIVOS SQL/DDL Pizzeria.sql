

create database pizzeria;
use pizzeria;
drop database pizzeria;

create table clientes  
(
OrdenID  int not null,
nombre varchar (45),
telefono int (11),
id_gusto int,
PRIMARY KEY (id_gusto)
);
drop table clientes;
insert into clientes values ('1','Maria','44319453','1'),
('2','Juan','33889927','2'),
('3','Lucas','43321543','5'),
('4','Pablo','44556633','4');

select*from clientes;

create table Venta(

  id int,
  fecha_venta  date not null,
  id_tipo_pizza int not null,
  cantidad_vendida int not null,
  precio double);
  
    insert into venta values ('1','2010-04-01','1','100','150'),
                                 ('2','2010-05-02','2','400','433'),
                                 ('4','2010-07-03','5','200','2400'),
							    ('5','2010-02-05','4','300','125');
                                
 select*from  venta;
  
  

create table tipoPizza( 
  id int auto_increment,
  primary key (id),
  id_tipo_pizza enum('1','2','5','4') ,
  id_gusto int,
  descripcion varchar(180)
       );
       
       insert into tipoPizza value ('1','1','2','pizza de morron'),
       ('2','2','3','pizza de muzzarella'),
('5','5','5','pizza de anana'),
('4','4','1','pizza de jamon');
       select*from tipoPizza;
    
       
create table empleados (
  id int auto_increment,
  nombre varchar(45),
  apellido varchar(45),
  horas_trabajadas int not null,
  primary key (id)
);
insert into empleados values ('1','Marcelo','Mayonesa','14'),
('2','Cassian','Andor','16'),
('4','Djinn','Jarin','23'),
('5','James','segundo','50');


      
alter table Venta add constraint fk_Venta_idPizzas foreign key (id_tipo_pizza) references tipoPizza(id);

alter table tipoPizza add constraint fk_orden_idEmpleado foreign key (id) references empleados(id);

alter table clientes add constraint fk_orden_idPizzas foreign key (id_gusto ) references Venta(id);


