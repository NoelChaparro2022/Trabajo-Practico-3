use pizzeria;
-- ------------------------------------------------------
insert into clientes values ('1','Maria','44319453','1'),
('2','Juan','33889927','2'),
('3','Lucas','43321543','5'),
('4','Pablo','44556633','4');
   select*from clientes;
-- ----------------------------------------------------

insert into venta values ('1','2010-04-01','1','100','150'),
('2','2010-05-02','2','400','433'),
('4','2010-07-03','5','200','2400'),
('5','2010-02-05','4','300','125');
   select*from venta;
-- ------------------------------------------------------------
 insert into tipoPizza value ('1','1','2','pizza de morron'),
('2','2','3','pizza de muzzarella'),
('5','5','5','pizza de anana'),
('4','4','1','pizza de jamon');
   select*from tipoPizza;
-- --------------------------------------------------------------
insert into empleados values ('1','Marcelo','Mayonesa','14'),
('2','Cassian','Andor','16'),
('4','Djinn','Jarin','23'),
('5','James','segundo','50');
   select*from empleados;