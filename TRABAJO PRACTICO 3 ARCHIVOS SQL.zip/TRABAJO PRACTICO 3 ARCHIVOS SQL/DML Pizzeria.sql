use pizzeria;




insert into tipoPizzas values('4','fugazzeta','250','contiene cebolla y parmesano'),
('5','morron','180','contiene muzarella y morron'),
('1','muzarella','150','contiene muzarella y oregano'),
('2','jamon','300','contiene jamon y oregano');

   insert into empleados values
   ('2','Juan','Salvo','20'),
   ('1','Matias','Heinz','35'),
   ('3','Marcelo','Mayonesa','10'),
   ('5','James','Gordon','60');

   insert into clientes values ('4','Marcos','44319453'),
   ('5','Camila','44359683'),
   ('1','Facundo','44225453'),
   ('2','Cass','1157354984');
   
   insert into ventas values ('1','4','2','2010-04-01','4','100','250') ,
('2','5','1','2010-04-11','5','40','180'),
('3','1','3','2010-05-12','1','250','150'),
('4','2','5','2010-03-18','2','180','300');
	select*from ventas;
   select*from tipoPizzas;
   select*from empleados;
   select*from clientes;