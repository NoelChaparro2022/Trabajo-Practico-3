use pizzeria;

-- selecciono cantidad de pizzas vendidas en total

select cantidad_vendida from venta;

-- cantidad de pizzas vendidas por id

select id,sum(cantidad_vendida) from venta group by id;

-- cantidad distinta de 0 de las cantidad vendida y agrupado por fecha
select fecha_venta as fecha,cantidad_vendida from venta group by fecha_venta having cantidad_vendida != 0;


-- id de las ventas enlazado a el id de los empleados
select * from venta v  join empleados e on v.id=e.id;


-- borrando el tipo de id de tipo de la pizza
delete from tipoPizza where id = 3;
select*from tipoPizza;


