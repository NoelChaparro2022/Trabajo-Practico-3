
drop database pizzeria;
create database pizzeria;
use pizzeria;
-- -----------------------------------------------------
drop table if exists clientes;
create table clientes  
(
id  int not null,
nombre varchar (45),
telefono int (11),
PRIMARY KEY (id)
);

select*from clientes;
-- -----------------------------------------------------
drop table if exists ventas;

create table ventas(

  id int,
  id_cliente int,
  id_empleado int,
  fecha_venta  date not null,
  id_tipo_pizza int not null,
  cantidad_vendida int not null,
  precio double);
  
 select*from  ventas;
  -- -----------------------------------------------------
drop table if exists tipoPizzas;

create table tipoPizzas( 
  id int auto_increment,
  primary key (id),
  tipo_pizza enum('fugazzeta','morron','muzarella','jamon') ,
  precio double,
 ingredientes varchar(180)
       );
       
       select*from tipoPizzas;
    -- -----------------------------------------------------
drop table if exists empleados;  

create table empleados (
  id int auto_increment,
  nombre varchar(45),
  apellido varchar(45),
  horas_trabajadas int not null,
  primary key (id)
);
      select*from empleados;
-- ------------------------------------------------------------------------------------------
      
alter table ventas add constraint fk_ventas_idPizzas foreign key (id_tipo_pizza) references tipoPizzas(id);

alter table ventas add constraint fk_idEmpleado foreign key (id_empleado) references empleados(id);

alter table ventas add constraint fk_orden_cliente foreign key (id_cliente) references clientes(id);



