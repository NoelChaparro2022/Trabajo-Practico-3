use pizzeria;


-- tipo de pizzas con ingredientes

select tipo_pizza as pizzas,
ingredientes from tipoPizzas ;

-- pizzas agrupadas por el precio entre tipo de pizza y ventas ordenado por el tipo de pizza

select tipo_pizza as pizzas,
v.precio as precioventa
from ventas v
join tipoPizzas t on v.precio =t.precio
order by  tipo_pizza;

-- selecciono cantidad de pizzas vendidas en total por id


select t.id,
v.cantidad_vendida as cantidaddepizzas
from ventas v
join tipoPizzas t on v.id_tipo_pizza =t.id
order by cantidaddepizzas ;


-- cantidad distinta de 0 de las cantidad vendida y agrupado por fecha
select fecha_venta as fecha,sum(cantidad_vendida) cantidad_vendida
from ventas 
where cantidad_vendida != 0
group by fecha_venta ;


-- id de las ventas u ordenes enlazado a el id de los empleados 
select v.id as numeroventas,v.id_empleado as IDdeventas ,e.id as empleados 
from ventas as v 
 join empleados e on v.id_empleado=e.id;


-- borrando el tipo de id de tipo de la pizza
delete from tipoPizzas where id = 3;

select*from tipoPizzas;



