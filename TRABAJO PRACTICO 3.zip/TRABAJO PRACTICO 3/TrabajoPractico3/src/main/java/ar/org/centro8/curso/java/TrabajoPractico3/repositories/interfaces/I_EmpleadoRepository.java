package ar.org.centro8.curso.java.TrabajoPractico3.repositories.interfaces;

import ar.org.centro8.curso.java.TrabajoPractico3.entities.Empleado;
import java.util.ArrayList;
import java.util.List;

public interface I_EmpleadoRepository {

    void save(Empleado empleado);

    void remove(Empleado empleado);

    void update(Empleado empleado);

    default Empleado getById(int id) {
        return getAll()
                .stream()
                .filter(e -> e.getId() == id)
                .findAny()
                .orElse(new Empleado());
    }

    List<Empleado> getAll();

    // nombre
    default List<Empleado> getLikeNombre(String nombre) {
        if (nombre == null)
            return new ArrayList<>();
        return getAll()
                .stream()
                .filter(e -> e
                        .getNombre()
                        .toLowerCase()
                        .contains(nombre.toLowerCase()))
                .toList();
    }

    // apellido
    default List<Empleado> getLikeApellido(String apellido) {
        if (apellido == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(e -> e
                        .getNombre()
                        .toLowerCase()
                        .contains(apellido.toLowerCase()))
                .toList();
    }

  
}
