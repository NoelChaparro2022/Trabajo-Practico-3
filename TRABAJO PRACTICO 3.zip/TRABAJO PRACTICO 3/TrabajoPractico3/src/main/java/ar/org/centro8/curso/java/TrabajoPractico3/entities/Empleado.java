package ar.org.centro8.curso.java.TrabajoPractico3.entities;

public class Empleado {

    private int id;
    private String nombre;
    private String apellido;
    private int horas_trabajadas;

    public Empleado() {

    }

    public Empleado(String nombre, String apellido, int horas_trabajadas) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.horas_trabajadas = horas_trabajadas;
    }

    public Empleado(int id, String nombre, String apellido, int horas_trabajadas) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.horas_trabajadas = horas_trabajadas;
    }

    @Override
    public String toString() {
        return "Empleado [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", horas_trabajadas="
                + horas_trabajadas + "]";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getHoras_trabajadas() {
        return horas_trabajadas;
    }

    public void setHoras_trabajadas(int horas_trabajadas) {
        this.horas_trabajadas = horas_trabajadas;
    }

}
