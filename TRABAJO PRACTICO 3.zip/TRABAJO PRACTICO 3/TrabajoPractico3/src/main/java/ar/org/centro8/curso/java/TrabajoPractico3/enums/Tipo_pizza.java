package ar.org.centro8.curso.java.TrabajoPractico3.enums;

public enum Tipo_pizza {
    fugazzeta,
    morron,
    muzarella,
    jamon

}
