package ar.org.centro8.curso.java.TrabajoPractico3.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.TrabajoPractico3.entities.TipoPizza;
import ar.org.centro8.curso.java.TrabajoPractico3.repositories.interfaces.I_TipoPizzaRepository;
import ar.org.centro8.curso.java.TrabajoPractico3.enums.Tipo_pizza;

public class TipoPizzaRepository implements I_TipoPizzaRepository {
    private Connection conn;

    public TipoPizzaRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(TipoPizza tipopizza) {
        if (tipopizza == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into tipoPizzas (tipo_pizza,precio,ingredientes) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, tipopizza.getTipo_pizza().toString());
            ps.setDouble(2, tipopizza.getPrecio());
            ps.setString(3, tipopizza.getIngredientes());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();

            if (rs.next())
                tipopizza.setId(rs.getInt(1));

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(TipoPizza tipopizza) {
        if (tipopizza == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete into tipoPizzas (tipo_pizza,precio,ingredientes) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, tipopizza.getTipo_pizza().toString());
            ps.setDouble(2, tipopizza.getPrecio());
            ps.setString(3, tipopizza.getIngredientes());
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(TipoPizza tipopizza) {
        if (tipopizza == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update tipoPizzas set tipo_pizza=?, precio=?, ingredientes=?, where id=?")) {
            ps.setString(1, tipopizza.getTipo_pizza().toString());
            ps.setDouble(2, tipopizza.getPrecio());
            ps.setString(3, tipopizza.getIngredientes());
            ps.setInt(4, tipopizza.getId());

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public List<TipoPizza> getAll() {
        List<TipoPizza> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select*from tipoPizzas;")) {
            while (rs.next()) {
                list.add(new TipoPizza(
                        rs.getInt("id"),
                        Tipo_pizza.valueOf(rs.getString("tipo_pizza")),
                        rs.getDouble("precio"),
                        rs.getString("ingredientes")));
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

}
