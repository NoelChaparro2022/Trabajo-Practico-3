package ar.org.centro8.curso.java.TrabajoPractico3.repositories.interfaces;

import ar.org.centro8.curso.java.TrabajoPractico3.entities.Cliente;
import java.util.ArrayList;
import java.util.List;

public interface I_ClienteRepository {

    void save(Cliente cliente); // insert

    void remove(Cliente cliente); // delete

    void update(Cliente cliente); // update

    default Cliente getById(int id) {
        return getAll()
                .stream()
                .filter(c -> c.getId() == id)
                .findAny()
                .orElse(new Cliente());
    }

    List<Cliente> getAll();

    // nombre
    default List<Cliente> getLikeNombre(String nombre) {
        if (nombre == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(c -> c
                        .getNombre()
                        .toLowerCase()
                        .contains(nombre.toLowerCase()))
                .toList();
    }

    // telefono
    default Cliente getByTelefono(int telefono) {
        return getAll()
                .stream()
                .filter(c -> c.getTelefono() == telefono)
                .findAny()
                .orElse(new Cliente());
    }

}
