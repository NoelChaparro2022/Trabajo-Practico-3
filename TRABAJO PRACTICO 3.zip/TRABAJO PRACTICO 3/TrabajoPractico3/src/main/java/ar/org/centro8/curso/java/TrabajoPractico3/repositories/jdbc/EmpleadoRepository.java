package ar.org.centro8.curso.java.TrabajoPractico3.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import ar.org.centro8.curso.java.TrabajoPractico3.entities.Empleado;
import ar.org.centro8.curso.java.TrabajoPractico3.repositories.interfaces.I_EmpleadoRepository;

public class EmpleadoRepository implements I_EmpleadoRepository {

    private Connection conn;

    public EmpleadoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Empleado empleado) {

        if (empleado == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into empleados (nombre,apellido,horas_trabajadas) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, empleado.getNombre());
            ps.setString(2, empleado.getApellido());
            ps.setInt(3, empleado.getHoras_trabajadas());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                empleado.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public void remove(Empleado empleado) {

        if (empleado == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete into empleados (nombre,apellido,horas_trabajadas) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, empleado.getNombre());
            ps.setString(2, empleado.getApellido());
            ps.setInt(3, empleado.getHoras_trabajadas());
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Empleado empleado) {
        if (empleado == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update empleados set nombre=?, apellido=?, horas_trabajadas=?, where id=?")) {
            ps.setString(1, empleado.getNombre());
            ps.setString(2, empleado.getApellido());
            ps.setInt(3, empleado.getHoras_trabajadas());
            ps.setInt(4, empleado.getId());
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public List<Empleado> getAll() {
        List<Empleado> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from empleados")) {
            while (rs.next()) {
                list.add(new Empleado(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getInt("horas_trabajadas")));
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

}
