package ar.org.centro8.curso.java.TrabajoPractico3.entities;

import ar.org.centro8.curso.java.TrabajoPractico3.enums.Tipo_pizza;

public class TipoPizza {
    private int id;
    private Tipo_pizza tipo_pizza;
    private double precio;
    private String ingredientes;

    public TipoPizza() {

    }

    public TipoPizza(Tipo_pizza tipo_pizza, double precio, String ingredientes) {
        this.tipo_pizza = tipo_pizza;
        this.precio = precio;
        this.ingredientes = ingredientes;
    }

    public TipoPizza(int id, Tipo_pizza tipo_pizza, double precio, String ingredientes) {
        this.id = id;
        this.tipo_pizza = tipo_pizza;
        this.precio = precio;
        this.ingredientes = ingredientes;
    }

    @Override
    public String toString() {
        return "TipoPizza [id=" + id + ", tipo_pizza=" + tipo_pizza + ", precio=" + precio + ", ingredientes="
                + ingredientes + "]";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Tipo_pizza getTipo_pizza() {
        return tipo_pizza;
    }

    public void setTipo_pizza(Tipo_pizza tipo_pizza) {
        this.tipo_pizza = tipo_pizza;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

}
