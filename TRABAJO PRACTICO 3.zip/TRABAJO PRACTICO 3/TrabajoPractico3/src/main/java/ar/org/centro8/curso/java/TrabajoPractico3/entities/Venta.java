package ar.org.centro8.curso.java.TrabajoPractico3.entities;

public class Venta {
    private int id;
    private int id_cliente;
    private int id_empleado;
    private String fecha_venta;
    private int id_tipo_pizza;
    private int cantidad_vendida;
    private double precio;

    public Venta() {

    }

    public Venta(int id_cliente, int id_empleado, String fecha_venta, int id_tipo_pizza, int cantidad_vendida,
            double precio) {
        this.id_cliente = id_cliente;
        this.id_empleado = id_empleado;
        this.fecha_venta = fecha_venta;
        this.id_tipo_pizza = id_tipo_pizza;
        this.cantidad_vendida = cantidad_vendida;
        this.precio = precio;
    }

    public Venta(int id, int id_cliente, int id_empleado, String fecha_venta, int id_tipo_pizza, int cantidad_vendida,
            double precio) {
        this.id = id;
        this.id_cliente = id_cliente;
        this.id_empleado = id_empleado;
        this.fecha_venta = fecha_venta;
        this.id_tipo_pizza = id_tipo_pizza;
        this.cantidad_vendida = cantidad_vendida;
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Venta [id=" + id + ", id_cliente=" + id_cliente + ", id_empleado=" + id_empleado + ", fecha_venta="
                + fecha_venta + ", id_tipo_pizza=" + id_tipo_pizza + ", cantidad_vendida=" + cantidad_vendida
                + ", precio="
                + precio + "]";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public int getId_empleado() {
        return id_empleado;
    }

    public void setId_empleado(int id_empleado) {
        this.id_empleado = id_empleado;
    }

    public String getFecha_venta() {
        return fecha_venta;
    }

    public void setFecha_venta(String fecha_venta) {
        this.fecha_venta = fecha_venta;
    }

    public int getId_tipo_pizza() {
        return id_tipo_pizza;
    }

    public void setId_tipo_pizza(int id_tipo_pizza) {
        this.id_tipo_pizza = id_tipo_pizza;
    }

    public int getCantidad_vendida() {
        return cantidad_vendida;
    }

    public void setCantidad_vendida(int cantidad_vendida) {
        this.cantidad_vendida = cantidad_vendida;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

}
