package ar.org.centro8.curso.java.TrabajoPractico3.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import ar.org.centro8.curso.java.TrabajoPractico3.entities.Venta;
import ar.org.centro8.curso.java.TrabajoPractico3.repositories.interfaces.I_VentaRepository;

public class VentaRepository implements I_VentaRepository {
    private Connection conn;

    public VentaRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Venta venta) {
        if (venta == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into ventas (id_cliente,id_empleado,fecha_venta,id_tipo_pizza,cantidad_vendida,precio) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, venta.getId_cliente());
            ps.setInt(2, venta.getId_empleado());
            ps.setString(3, venta.getFecha_venta());
            ps.setInt(4, venta.getId_tipo_pizza());
            ps.setInt(5, venta.getCantidad_vendida());
            ps.setDouble(6, venta.getPrecio());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                venta.setId(rs.getInt(1));

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(Venta venta) {
        if (venta == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete into ventas (id_cliente,id_empleado,fecha_venta,id_tipo_pizza,cantidad_vendida,precio) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, venta.getId_cliente());
            ps.setInt(2, venta.getId_empleado());
            ps.setString(3, venta.getFecha_venta());
            ps.setInt(4, venta.getId_tipo_pizza());
            ps.setInt(5, venta.getCantidad_vendida());
            ps.setDouble(6, venta.getPrecio());
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Venta venta) {
        if (venta == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update ventas set id_cliente=?,id_empleado=?,fecha_venta=?,id_tipo_pizza=?,cantidad_vendida=?,precio=?, where id=?")) {
            ps.setInt(1, venta.getId_cliente());
            ps.setInt(2, venta.getId_empleado());
            ps.setString(3, venta.getFecha_venta());
            ps.setInt(4, venta.getId_tipo_pizza());
            ps.setInt(5, venta.getCantidad_vendida());
            ps.setDouble(6, venta.getPrecio());

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public List<Venta> getAll() {
        List<Venta> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from ventas")) {

            while (rs.next()) {
                list.add(new Venta(
                        rs.getInt("id"),
                        rs.getInt("id_cliente"),
                        rs.getInt("id_empleado"),
                        rs.getString("fecha_venta"),
                        rs.getInt("id_tipo_pizza"),
                        rs.getInt("cantidad_vendida"),
                        rs.getDouble("precio")));
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

}
