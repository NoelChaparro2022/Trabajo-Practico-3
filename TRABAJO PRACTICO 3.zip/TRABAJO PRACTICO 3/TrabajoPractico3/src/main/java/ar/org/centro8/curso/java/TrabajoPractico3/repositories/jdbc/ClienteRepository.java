package ar.org.centro8.curso.java.TrabajoPractico3.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.TrabajoPractico3.entities.Cliente;
import ar.org.centro8.curso.java.TrabajoPractico3.repositories.interfaces.I_ClienteRepository;

public class ClienteRepository implements I_ClienteRepository {

    private Connection conn;

    public ClienteRepository(Connection conn) {

        this.conn = conn;
    }

    @Override

    public List<Cliente> getAll() {
        List<Cliente> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select*from clientes")) {
            while (rs.next()) {
                list.add(new Cliente(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getInt("telefono")));

            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void save(Cliente cliente) {
        {
            if (cliente == null)
                return;
            try (PreparedStatement ps = conn.prepareStatement(
                    "insert into clientes (nombre,telefono) values (?,?)",
                    PreparedStatement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, cliente.getNombre());
                ps.setInt(2, cliente.getTelefono());
                ps.execute();
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next())
                    cliente.setId(rs.getInt(1));
            } catch (Exception e) {
                System.out.println(e);
            }
        }

    }

    @Override
    public void remove(Cliente cliente) {
        {
            if (cliente == null)
                return;
            try (PreparedStatement ps = conn.prepareStatement(
                    "delete into clientes (nombre,telefono) values (?,?)",
                    PreparedStatement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, cliente.getNombre());
                ps.setInt(2, cliente.getTelefono());

            } catch (Exception e) {
                System.out.println(e);
            }
        }

    }

    @Override
    public void update(Cliente cliente) {
        if (cliente == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update clientes set nombre=?, telefono=? where id=?")) {
            ps.setString(1, cliente.getNombre());
            ps.setInt(2, cliente.getTelefono());
            ps.setInt(3, cliente.getId());
        } catch (Exception e) {
            System.out.println(e);
        }

    }

}