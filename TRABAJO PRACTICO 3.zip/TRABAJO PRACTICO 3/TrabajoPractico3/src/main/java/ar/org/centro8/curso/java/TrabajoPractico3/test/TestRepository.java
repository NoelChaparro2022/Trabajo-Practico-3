package ar.org.centro8.curso.java.TrabajoPractico3.test;

import java.sql.Connection;

import org.springframework.util.SocketUtils;

import ar.org.centro8.curso.java.TrabajoPractico3.connector.Connector;
import ar.org.centro8.curso.java.TrabajoPractico3.entities.Cliente;
import ar.org.centro8.curso.java.TrabajoPractico3.entities.Empleado;
import ar.org.centro8.curso.java.TrabajoPractico3.entities.TipoPizza;
import ar.org.centro8.curso.java.TrabajoPractico3.entities.Venta;
import ar.org.centro8.curso.java.TrabajoPractico3.enums.Tipo_pizza;
import ar.org.centro8.curso.java.TrabajoPractico3.repositories.interfaces.I_EmpleadoRepository;
import ar.org.centro8.curso.java.TrabajoPractico3.repositories.interfaces.I_ClienteRepository;
import ar.org.centro8.curso.java.TrabajoPractico3.repositories.interfaces.I_VentaRepository;
import ar.org.centro8.curso.java.TrabajoPractico3.repositories.interfaces.I_TipoPizzaRepository;
import ar.org.centro8.curso.java.TrabajoPractico3.repositories.jdbc.ClienteRepository;
import ar.org.centro8.curso.java.TrabajoPractico3.repositories.jdbc.TipoPizzaRepository;
import ar.org.centro8.curso.java.TrabajoPractico3.repositories.jdbc.VentaRepository;
import ar.org.centro8.curso.java.TrabajoPractico3.repositories.jdbc.EmpleadoRepository;

public class TestRepository {

    public static void main(String[] args) {
        Connection conn = Connector.getConnection();
        I_ClienteRepository clienteRepository = new ClienteRepository(conn);
        Cliente cliente = new Cliente("Juan", 11456789);
        clienteRepository.save(cliente);
        System.out.println(cliente);

        clienteRepository.remove(clienteRepository.getById(1));

        cliente = clienteRepository.getById(2);
        if (cliente != null && cliente.getId() != 0) {
            cliente.setNombre("Tobey");
            cliente.setTelefono(19984322);
            clienteRepository.update(cliente);

        }

        System.out.println("-----------------------------------------------------------------------------------");
        clienteRepository.getAll().forEach(System.out::println);

        System.out.println("----------------------------------------------------------------------------------");
        clienteRepository.getLikeNombre("ey")
                .forEach(System.out::println);
        System.out.println("-----------------------------------------------------------------------------------");
        clienteRepository.getByTelefono(99);

        System.out.println("-----------------------------------------------------------------------");

        I_EmpleadoRepository empleadoRepository = new EmpleadoRepository(conn);

        Empleado empleado = new Empleado("Charles", "Xavier", 45);
        empleadoRepository.save(empleado);
        System.out.println(empleado);

        empleadoRepository.remove(empleadoRepository.getById(1));

        empleado = empleadoRepository.getById(2);
        if (empleado != null && empleado.getId() != 0) {
            empleado.setNombre("Bart");
            empleado.setApellido("Simpson");
            empleado.setHoras_trabajadas(40);
            empleadoRepository.update(empleado);

        }

        System.out.println("------------------------------------------------------------------------------");
        empleadoRepository.getAll().forEach(System.out::println);

        System.out.println("---------------------------------------------------------------------");
        empleadoRepository.getLikeNombre("Bar")

                .forEach(System.out::println);

        System.out.println("-----------------------------------------------------------------------------");

        I_TipoPizzaRepository tipoPizzaRepository = new TipoPizzaRepository(conn);

        TipoPizza tipopizza = new TipoPizza(Tipo_pizza.jamon, 1660, "contiene jamon y oregano");

        tipoPizzaRepository.save(tipopizza);
        System.out.println(tipopizza);

        tipoPizzaRepository.remove(tipoPizzaRepository.getById(2));

        tipopizza = tipoPizzaRepository.getById(3);
        if (tipopizza != null && tipopizza.getId() != 0) {
            tipopizza.setIngredientes("jamon");
            tipopizza.setPrecio(1700);
            tipoPizzaRepository.update(tipopizza);

            System.out.println("---------------------------------------------------------------------------------");

            tipoPizzaRepository.getAll().forEach(System.out::println);

            System.out.println("---------------------------------------------------------------------------------");

            tipoPizzaRepository.getLikeIngredientes("muzzarella")
                    .forEach(System.out::println);

            System.out.println("------------------------------------");

            tipoPizzaRepository.getLikeTipodepizza(Tipo_pizza.jamon)
                    .forEach(System.out::println);

            System.out.println("----------------------------------------------------------------");

            I_VentaRepository ventaRepository = new VentaRepository(conn);

            Venta venta = new Venta(2, 1, "2022-10-3", 3, 130, 1700);

            ventaRepository.remove(ventaRepository.getById(1));

            venta = ventaRepository.getById(3);
            if (venta != null && venta.getId() != 0) {

                venta.setFecha_venta("2022-11-15");
                venta.setCantidad_vendida(1300);
                ventaRepository.update(venta);

                System.out.println("----------------------------------------------------------------------------");

                ventaRepository.getAll().forEach(System.out::println);

                System.out.println("----------------------------------------------------------------------------");

                ventaRepository.getLikeFechaVenta("2022-11-15")
                        .forEach(System.out::println);

            }

        }

    }
}