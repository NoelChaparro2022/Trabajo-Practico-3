package ar.org.centro8.curso.java.TrabajoPractico3.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import ar.org.centro8.curso.java.TrabajoPractico3.entities.Venta;

public interface I_VentaRepository {

    void save(Venta venta);

    void remove(Venta venta);

    void update(Venta venta);

    default Venta getById(int id) {
        return getAll()
                .stream()
                .filter(v -> v.getId() == id)
                .findAny()
                .orElse(new Venta());

    }

    List<Venta> getAll();

    // fecha venta
    default List<Venta> getLikeFechaVenta(String fecha_venta) {
        if (fecha_venta == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(t -> t.getFecha_venta() == fecha_venta)
                .toList();
    }

    // precio
    default Venta getByPrecio(double precio) {
        return getAll()
                .stream()
                .filter(v -> v.getPrecio() == precio)
                .findAny()
                .orElse(new Venta());

    }

}
