package ar.org.centro8.curso.java.TrabajoPractico3.repositories.interfaces;

import ar.org.centro8.curso.java.TrabajoPractico3.entities.TipoPizza;

import ar.org.centro8.curso.java.TrabajoPractico3.enums.Tipo_pizza;
import java.util.ArrayList;
import java.util.List;

public interface I_TipoPizzaRepository {

    void save(TipoPizza tipopizza);

    void remove(TipoPizza tipopizza);

    void update(TipoPizza tipopizza);

    default TipoPizza getById(int id) {
        return getAll()
                .stream()
                .filter(t -> t.getId() == id)
                .findAny()
                .orElse(new TipoPizza());
    }

    List<TipoPizza> getAll();

    // tipo_pizza
    default List<TipoPizza> getLikeTipodepizza(Tipo_pizza tipo_pizza) {
        if (tipo_pizza == null)
            return new ArrayList();
        return getAll()
                .stream() // from
                .filter(t -> t.getTipo_pizza() == tipo_pizza) // where
                .toList();
    }

    // ingredientes

    default List<TipoPizza> getLikeIngredientes(String ingredientes) {
        if (ingredientes == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(t -> t.getIngredientes() == ingredientes)
                .toList();
    }

}
