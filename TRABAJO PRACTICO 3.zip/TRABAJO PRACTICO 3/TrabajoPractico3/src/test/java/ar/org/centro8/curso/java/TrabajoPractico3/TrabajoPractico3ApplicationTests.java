package ar.org.centro8.curso.java.TrabajoPractico3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoPractico3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
